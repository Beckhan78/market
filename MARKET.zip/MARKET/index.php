<?php include 'header.php'; ?>

<div class="contenedor">
    <div class="fila">
        <div class="columnas cardtv">
            <div class="titulocard">TELEVISORES</div>
            <div><img class="imagenescentroindex" src="https://tse2.mm.bing.net/th?id=OIP.MnjG4eESLs_NNNVi950n0QHaE8&pid=Api&P=0&h=180"></div>
            <div class="vermore"><a href="televisores.php">ver más</a></div>
        </div>
        <div class="columnas cardcel">
            <div class="titulocard">CELULARES</div>
            <div><img class="imagenescentroindex" src="https://tse2.mm.bing.net/th?id=OIP.HfvmZ6DbsydseaBVxjjx0QHaFA&pid=Api&P=0&h=180"></div>
            <div class="vermore"><a href="celulares.php">ver más</a></div>
        </div>
        <div class="columnas cardaudif">
            <div class="titulocard">AUDIFONOS</div>
            <div><img class="imagenescentroindex" src="https://tse2.mm.bing.net/th?id=OIP.3i-IilSDkcXa8GoEAWtCNgHaEK&pid=Api&P=0&h=180"></div>
            <div class="vermore"> <a href="audifonos.php">ver más</a>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>