<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Pixelify+Sans:wght@600&display=swap" rel="stylesheet">
</head>
<body>
    <nav class="navbar">
        <ul id="navlist">
            <li><a href="index.php fron-size: 50px">Inicio</a></li>
            <li><a href="televisores.php">Televisores</a></li>
            <li><a href="celulares.php">Celulares</a></li>
            <li><a href="audifonos.php">Audifonos</a></li>
            <li><a href="contacto.php">Contacto</a></li>
        </ul>
    </nav>