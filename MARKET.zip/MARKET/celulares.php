<?php include 'header.php' ?>
<?php
$titulo = "CELULARES";
?>
<div class="contenedor">
<h2><?php echo $titulo ?></h2>
    <div class="fila">
        <div class="columnas fondodecard">
            <div><img class="imagenescentroindex" src="https://falabella.scene7.com/is/image/FalabellaPE/gsc_119344266_2311197_1?wid=800&hei=800&qlt=70"></div>
            <div class="titulocard">Samsung Galaxy S23 ultra 5G 512gb 12gb ram</div>
            <div class="vermore contactarbutton"><a href="contacto.php">CONTACTAR</a></div>
        </div>
        <div class="columnas fondodecard">
            <div><img class="imagenescentroindex" src="https://falabella.scene7.com/is/image/FalabellaPE/gsc_122612030_3399000_1?wid=800&hei=800&qlt=70"></div>
            <div class="titulocard">Smartphone HONOR 70 8+256GB verde</div>
            <div class="vermore contactarbutton"><a href="contacto.php">CONTACTAR</a></div>
        </div>
        <div class="columnas fondodecard">
            <div><img class="imagenescentroindex" src="https://falabella.scene7.com/is/image/FalabellaPE/19983093_1?wid=800&hei=800&qlt=70"></div>
            <div class="titulocard">Apple iPhone 
                <br>14 128GB</div>
            <div class="vermore contactarbutton"><a href="contacto.php">CONTACTAR</a></div>
        </div>
    </div>
    <div class="fila fondodecard">
        <div class="columnas fondodecard">
            <div><img class="imagenescentroindex" src="https://falabella.scene7.com/is/image/FalabellaPE/19729703_1?wid=800&hei=800&qlt=70"></div>
            <div class="titulocard">TGalaxy S23+ 512GB 
                <br>8GB</div>
            <div class="vermore contactarbutton"><a href="contacto.php">CONTACTAR</a></div>
        </div>
        <div class="columnas fondodecard">
            <div><img class="imagenescentroindex" src="https://falabella.scene7.com/is/image/FalabellaPE/19316384_1?wid=800&hei=800&qlt=70"></div>
            <div class="titulocard">Apple iPhone 14 Pro Max 128GB.</div>
            <div class="vermore contactarbutton"><a href="contacto.php">CONTACTAR</a></div>
        </div>
        <div class="columnas fondodecard">
            <div><img class="imagenescentroindex" src="https://e39a9f00db6c5bc097f9-75bc5dce1d64f93372e7c97ed35869cb.ssl.cf1.rackcdn.com/43002041_1-LFgQWqmX-medium.jpg"></div>
            <div class="titulocard">Smartphone Honor X6S 128Gb 4GB Nano Sim</div>
            <div class="vermore contactarbutton"><a href="contacto.php">CONTACTAR</a></div>
        </div>
    </div>
</div>

<?php include 'footer.php' ?>