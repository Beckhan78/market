<?php include 'header.php'; ?>
<?php
$titulo = "TELEVISORES";
?>
<div class="contenedor">
<h2><?php echo $titulo ?></h2>
    <div class="fila">
        <div class="columnas fondodecard">
            <div><img class="imagenescentroindex" src="https://falabella.scene7.com/is/image/FalabellaPE/19844530_01?wid=800&hei=800&qlt=70"></div>
            <div class="titulocard">Televisor Samsung Smart TV 65" Crystal UHD 4K.</div>
            <div class="vermore contactarbutton"><a href="contacto.php">CONTACTAR</a></div>
        </div>
        <div class="columnas fondodecard">
            <div><img class="imagenescentroindex" src="https://s7d2.scene7.com/is/image/TottusPE/42671194_1?wid=800&hei=800&qlt=70"></div>
            <div class="titulocard">Televisor Samsung Smart TV 65" UHD 4K.</div>
            <div class="vermore contactarbutton"><a href="contacto.php">CONTACTAR</a></div>
        </div>
        <div class="columnas fondodecard">
            <div><img class="imagenescentroindex" src="https://s7d2.scene7.com/is/image/TottusPE/42687406_1?wid=800&hei=800&qlt=70"></div>
            <div class="titulocard">Televisor Samsung 43" Led Fhd Smart Tv.</div>
            <div class="vermore contactarbutton"><a href="contacto.php">CONTACTAR</a></div>
        </div>
    </div>
    <div class="fila fondodecard">
        <div class="columnas fondodecard">
            <div><img class="imagenescentroindex" src="https://s7d2.scene7.com/is/image/TottusPE/43059422_1?wid=800&hei=800&qlt=70"></div>
            <div class="titulocard">Televisor JVC Led 32" HD Google Tv.</div>
            <div class="vermore contactarbutton"><a href="contacto.php">CONTACTAR</a></div>
        </div>
        <div class="columnas fondodecard">
            <div><img class="imagenescentroindex" src="https://falabella.scene7.com/is/image/FalabellaPE/19786914_02?wid=800&hei=800&qlt=70"></div>
            <div class="titulocard">Xiaomi TV A Pro 55" LED UHD 4K SMART GOOGLE Tv.</div>
            <div class="vermore contactarbutton"><a href="contacto.php">CONTACTAR</a></div>
        </div>
        <div class="columnas fondodecard">
            <div><img class="imagenescentroindex" src="https://falabella.scene7.com/is/image/FalabellaPE/19844528_01?wid=800&hei=800&qlt=70"></div>
            <div class="titulocard">Televisor Samsung Smart TV 55" QLED 4K.</div>
            <div class="vermore contactarbutton"><a href="contacto.php">CONTACTAR</a></div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>